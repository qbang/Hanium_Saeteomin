package com.example.hanium_saeteomin.network;

public class RequestClickLike {
    String board_id;

    public RequestClickLike(String board_id){
        this.board_id = board_id;
    }
}
