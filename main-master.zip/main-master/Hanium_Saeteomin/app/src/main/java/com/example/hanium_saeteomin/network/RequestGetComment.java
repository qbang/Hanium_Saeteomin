package com.example.hanium_saeteomin.network;

public class RequestGetComment {
    String board_id;

    public RequestGetComment(String board_id) {
        this.board_id = board_id;
    }
}
