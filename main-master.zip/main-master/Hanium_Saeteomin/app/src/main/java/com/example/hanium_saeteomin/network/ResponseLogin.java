package com.example.hanium_saeteomin.network;

public class ResponseLogin {
    Data data;
    String result;
}

class Data{
    String user_id;
    String user_name;
    String user_password;
}
