package com.example.hanium_saeteomin.network;

public class RequestGetTodayWord {
    String word_date;

    public RequestGetTodayWord(String word_date){
        this.word_date = word_date;
    }
}
