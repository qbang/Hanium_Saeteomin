package com.example.hanium_saeteomin.network;

public class RequestGetQuizList {
    String user_id;

    public RequestGetQuizList(String user_id){
        this.user_id = user_id;
    }
}
